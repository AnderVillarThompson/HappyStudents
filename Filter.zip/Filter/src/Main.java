import javax.swing.*;


public class Main {
    public static void main(String[] args) {


        String[][] StudentNames = NamesLoader.getNumOfRowsCols("/Users/ander/Google Drive/Maastricht Science Programme/Year 2/Period 3/Filter/StudentNames.csv");
        String[][] StudentChoices = ChoiceLoader.getNumOfRowsCols("/Users/ander/Google Drive/Maastricht Science Programme/Year 2/Period 3/Filter/StudentChoices.csv");


        //Checks for only correct ID's
        for (int i = 0; i < StudentNames.length; i++) {
            int count = 0;
            for (int j = 0; j < StudentChoices.length; j++) {
                if (StudentNames[i][0].equals(StudentChoices[j][0])) {
                    count++;
                }
            }
            if(count == 0){
                StudentNames[i][2] = "Unknown ID";
                for (int j = 0; j < StudentChoices.length; j++) {
                    if (StudentNames[i][1].equals(StudentChoices[j][1])) {
                        count++;
                    }
                }
                if (count == 0) {
                    StudentNames[i][2] = "Unknown Name and ID";
                }
                else if (count == 1) {
                    StudentNames[i][2] = "0";
                    for (int j = 0; j < StudentChoices.length; j++) {
                        if (StudentNames[i][1].equals(StudentChoices[j][1])) {
                            StudentChoices[j][0]=StudentNames[i][0];
                            StudentChoices[j][7] = "0";
                            StudentChoices[j][8] = "0";
                        }
                    }
                    StudentChoices = deletion(StudentChoices, StudentNames[i][0]);
                }
                else if (count > 1) {
                    StudentNames[i][2] = "0";
                    int j = 0;
                    while (count > 1) {
                        if (StudentNames[i][1].equals(StudentChoices[j][1])) {
                            StudentChoices[j][7] = "invalid";
                            StudentChoices[j][8] = "invalid";
                            count--;
                        }
                        j++;
                    }
                    while (count != 0) {
                        if (StudentNames[i][1].equals(StudentChoices[j][1])) {
                            StudentChoices[j][7] = "0";
                            StudentChoices[j][8] = "0";
                            StudentChoices[j][0]=StudentNames[i][0];
                            StudentNames[i][2] = "0";
                            count--;
                        }
                        j++;
                    }
                    StudentChoices = deletion(StudentChoices, StudentNames[i][0]);
                }
            }
            else if (count == 1) {
                StudentNames[i][2] = "0";
                for (int j = 0; j < StudentChoices.length; j++) {
                    if (StudentNames[i][0].equals(StudentChoices[j][0])) {
                        StudentChoices[j][1]=StudentNames[i][1];
                        StudentChoices[j][7] = "0";
                        StudentChoices[j][8] = "0";
                    }
                }
                StudentChoices =deletion(StudentChoices,StudentNames[i][0]);
            }
            else if (count > 1) {
                StudentNames[i][2] = "0";
                int j = 0;
                while (count > 1) {
                    if (StudentNames[i][0].equals(StudentChoices[j][0])) {
                        StudentChoices[j][7] = "invalid";
                        StudentChoices[j][8] = "invalid";
                        count--;
                    }
                    j++;
                }
                while (count != 0) {
                    if (StudentNames[i][0].equals(StudentChoices[j][0])) {
                        StudentChoices[j][1]=StudentNames[i][1];
                        StudentChoices[j][7] = "0";
                        StudentChoices[j][8] = "0";
                        StudentNames[i][2] = "0";
                        count--;
                    }
                    j++;
                }
                StudentChoices =deletion(StudentChoices,StudentNames[i][0]);
            }
        }




        //Check
        for (int i = 0; i <StudentNames.length; i++) {
            if (StudentNames[i][2].equals("Unknown Name and ID")) {
                double ID = 0;
                double NAME =0;
                int jay=0;
                for (int j = 0; j < StudentChoices.length; j++) {
                    if (StudentChoices[j][7].equals("-1") && StudentChoices[j][8].equals("-1")) {
                        double checkID = LockMatch.lock_match(StudentNames[i][0],StudentChoices[j][0]);
                        double checkNAME = LockMatch.lock_match(StudentNames[i][1],StudentChoices[j][1]);
                        if (checkNAME>NAME){
                            NAME=checkNAME;
                            jay = j;
                        }
                    }
                }
                String[] options = new String[]{"Yes", "No"};
                int response = JOptionPane.showOptionDialog(null, "There is a conflict with student: \n" + StudentNames[i][0] + "   "+StudentNames[i][1]+"\n\n"
                                + "This student was not found with an entry. \nHowever, it is possible that the following entry is the student in question: \n\n"+
                                    StudentChoices[jay][0]+"    "+StudentChoices[jay][1]+"\n\nWould you like to substitute?", "Incorrect entry",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                        null, options, options[0]);
                if (response == 0) {
                    StudentNames[i][2]="0";
                    StudentChoices[jay][0]=StudentNames[i][0];
                    StudentChoices[jay][1]=StudentNames[i][1];
                    StudentChoices[jay][7] = "0";
                    StudentChoices[jay][8] = "0";

                }
                else if (response ==1){
                    StudentNames[i][2]="Student not found";
                    StudentChoices[jay][7] = "invalid";
                    StudentChoices[jay][8] = "invalid";
                }
            }
        }
        for (int i = 0; i<StudentChoices.length; i++){
            if (StudentChoices[i][7].equals("-1")&&StudentChoices[i][7].equals("-1")){
                StudentChoices[i][7] = "invalid";
                StudentChoices[i][8] = "invalid";
            }
        }



        for (int i =0;i<StudentChoices.length;i++){
            for (int j = 0 ; j<9;j++) {
                System.out.print(StudentChoices[i][j]+"\t");
            }
            System.out.println();
        }
        System.out.println();
        for (int i =0;i<StudentNames.length;i++){
            for (int j = 0 ; j<3;j++) {
                System.out.print(StudentNames[i][j]+"\t");
            }
            System.out.println();
        }



    }

    public static String[][] deletion(String[][] StudentChoices,String ID) {
        for (int i = 0 ; i<StudentChoices.length;i++){
            if (!StudentChoices[i][7].equals("0")&&!StudentChoices[i][8].equals("0")&&StudentChoices[i][0].equals(ID)){
                StudentChoices[i][7] = "invalid";
                StudentChoices[i][8] = "invalid";
            }
        }
        return StudentChoices;
    }
}
