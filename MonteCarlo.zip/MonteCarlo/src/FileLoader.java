import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class FileLoader {

    public static String Check (String filename){

        String re = null;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));

            String line=in.readLine();



            while (line != null){

                re+=line+"\t";
                line = in.readLine();
            }
            in.close();

        } catch (Exception d) {
            JOptionPane.showMessageDialog(null, "An error happened, here comes some info to debug it:" +
                    "\n*Check in message section below*");
            d.printStackTrace();
        }
        return re;
    }

    public static String Load (String filename) {
        String list="";
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
            String line=null;
            for (int i = 0; i <3 ; i++){
                line = in.readLine();
            }

            while (line != null){
                list+=line+"\t";
                line=in.readLine();
            }
            in.close();






        } catch (Exception d) {
            JOptionPane.showMessageDialog(null, "An error happened, here comes some info to debug it:" +
                    "\n*Check in message section below*");
            d.printStackTrace();
        }
        return list;

    }
}
