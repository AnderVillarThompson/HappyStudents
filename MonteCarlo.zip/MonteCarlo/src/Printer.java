import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;

public class Printer {


    private final String outFileName;

    public Printer(final String outFileName) {
        this.outFileName = outFileName;
    }

    public void parsestats(int [][] finale,int length) {
        try {
            FileWriter fw = new FileWriter(outFileName);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);

            String string="Project\tFirst\tSecond\tThird\tFourth\tFifth\tMin\tMax";
            out.println(string);
            string="";

            for (int i = 0; i<length; i++){
                string += finale[i][0];
                for (int j = 1; j<9; j++) {
                    string += "\t"+finale[i][j];

                }
                out.println(string);
                string="";

            }

            out.close();
        } catch (Exception e) {
            System.out.println("An error happened, here comes some info to debug it:");
            e.printStackTrace();

        }
    }

    public void parsechoices(int [][] finale,int length) {
        try {
            FileWriter fw = new FileWriter(outFileName);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);

            String string="Student\tFirst\tSecond\tThird\tFourth\tFifth\tProject";
            out.println(string);
            string="";

            for (int i = 0; i<length; i++){
                string += finale[i][0];
                for (int j = 1; j<8; j++) {
                    string += "\t"+finale[i][j];

                }
                out.println(string);
                string="";

            }

            out.close();
        } catch (Exception e) {
            System.out.println("An error happened, here comes some info to debug it:");
            e.printStackTrace();

        }
    }
}
