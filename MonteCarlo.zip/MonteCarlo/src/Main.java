import javax.swing.*;
import java.io.File;
import java.util.*;
public class Main {

    public static void main(String[] args) {

        Random random = new Random();
        //String fileName = JOptionPane.showInputDialog(null, "Name of the file")+".txt";
       // int options = Integer.parseInt(JOptionPane.showInputDialog(null, "Number of options"));
        //String filelim =JOptionPane.showInputDialog(null, "limit file")+".txt";
String fileName="Trial.txt";
int options = 35;
String filelim = "Limits.txt";
int times=1000000000;

        String choice [];
        choice = FileLoader.Load(fileName).split("\t");

        int[][] choices = new int[choice.length/6][8];
        int k = 0;
        for (int i = 0; i<choice.length/6; i++){
            for (int j = 0; j<6; j++) {
                choices[i][j]=Integer.parseInt(choice[k]);
                k++;
            }
        }

        int[][] stats = new int[options][9];

        String limits [];
        limits = FileLoader.Check(filelim).split("\t");
        limits[0]="0";
        for (int i = 0;i<choice.length/6; i++ ){
            for (int j = 1; j<6; j++){
                stats[choices[i][j]-1][j]++;
            }
        }
        for (int i = 0;i<options; i++ ){
            stats[i][8] = 0;
        }
        for (int i  =0; i<options;i++){
            stats[i][0]=i+1;
        }
        int [][]SAVE=null;
        double min=5.0;


        //SORTING SECTION


        //Number of lööps
        for(int goes = 1; goes<=times;goes++) {

            //Resetting the options
            for (int i = 0; i<choice.length/6; i++){
                choices[i][6]=0;
                choices[i][7]=0;
            }

            // To reset the limits

            k=0;
            for (int i = 0;i<options;i++){
                for(int j = 6;j<8;j++ ){
                    stats[i][j]=Integer.parseInt(limits[k]);
                    k++;
                }
            }
            int print = 0;
            boolean cont = true;
            while(cont) {


                //Selecting a random row
                int row = random.nextInt(choice.length / 6);


                //If student is already selected, select another student
                while (choices[row][6] != 0) {
                    row = random.nextInt(choice.length / 6);
                }

                // Check if all options are available, if not, restart
                cont = false;
                for (int i = 1; i <= 5; i++) {
                    if (stats[choices[row][i]-1][7] > 0) {
                        cont = true;
                    }
                }

                //If true, there will randomly be selected a row
                int col = 1 + random.nextInt(5);
                while (stats[choices[row][col]-1][7] <= 0 && cont) {
                    col = 1 + random.nextInt(5);
                }


                if(cont){
                    choices[row][6]=stats[choices[row][col]-1][0];
                    choices[row][7]=col;
                    stats[choices[row][col]-1][7]--;
                    print++;
                }

                //Print if done as many times as students
                if (print == choice.length / 6){
                    double sum=0;
                    for(int o = 0; o<choice.length/6;o++){
                        sum+=choices[o][7];
                    }
                    sum/=choice.length/6.0;

                    if(sum<2.5) {

                        Printer ar = new Printer("Choices" + goes + ".txt");
                        ar.parsechoices(choices, choice.length / 6);
                      System.out.println(sum+"\t"+goes);

                    }
                    cont=false;
                }

            }
        }
        
        //print(stats,options,choices,choice);


    }







    public static void print(int [][] stats,int options, int [][] choices,String [] choice){
        Printer fr = new Printer("Stats.txt");
        fr.parsestats(stats,options);

        Printer ar = new Printer("Choices.txt");
        ar.parsechoices(choices,choice.length/6);
    }


}
