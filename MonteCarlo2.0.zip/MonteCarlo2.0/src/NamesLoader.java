public class NamesLoader {
}
