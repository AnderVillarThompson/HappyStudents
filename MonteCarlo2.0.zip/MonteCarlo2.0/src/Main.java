import javax.swing.*;
import java.io.File;
import java.util.*;
public class Main {

    public static void main(String[] args) {

        Random random = new Random();
        //String fileName = JOptionPane.showInputDialog(null, "Location of the student choices CSV file");
        String [][]SAVECHOICES=null;
        String [][]SAVEPROJECTS=null;
        int zeroes = 1000;
        double expohappy = 6^4;
        double happy = 6;



        //SORTING
        final double startTime = System.currentTimeMillis();



        for (int repeat = 0; repeat < 100;repeat++) {
            String [][] ProjectStatistics=ProjectsLoader.getNumOfRowsCols("/Users/ander/Google Drive/Maastricht Science Programme/Year 2/Period 3/MonteCarlo2.0/ProjectInfo.csv");

//            for (int Rowc=0; Rowc<StudentChoices.length;Rowc++){
//                System.out.print(StudentChoices[Rowc][0]+ "\t"+StudentChoices[Rowc][1]+ "\t"+StudentChoices[Rowc][7]+ "\t"+StudentChoices[Rowc][8]);
//                System.out.println();
//            }
            boolean cont = false;
            while (!cont) {
                cont = true;
                String [][]StudentChoices=ChoiceLoader.getNumOfRowsCols("/Users/ander/Google Drive/Maastricht Science Programme/Year 2/Period 3/MonteCarlo2.0/StudentChoices.csv");
                for (int selection = 2; selection < 7; selection++) {
                    boolean go = false;
                    for (int check = 0; check < StudentChoices.length; check++) {
                        if (StudentChoices[check][8].equals("0")) {
                            go = true;
                        }
                    }
                    if (go) {
                        for (int i = 0; i < ProjectStatistics.length; i++) {
                            int count = 0;
                            for (int a = 0; a < StudentChoices.length; a++) {
                                if (StudentChoices[a][selection].equals(ProjectStatistics[i][0]) && StudentChoices[a][7].equals("0") && StudentChoices[a][8].equals("0")) {
                                    count++;
                                }
                            }
                            if (!ProjectStatistics[i][2].equals("0")) {
                                if (count <= Integer.parseInt(ProjectStatistics[i][2])) {
                                    ProjectStatistics[i][2] = "" + (Integer.parseInt(ProjectStatistics[i][2]) - count);
                                    for (int k = 0; k < StudentChoices.length; k++) {
                                        if (StudentChoices[k][selection].equals(ProjectStatistics[i][0]) && StudentChoices[k][7].equals("0") && StudentChoices[k][8].equals("0")) {
                                            StudentChoices[k][7] = ProjectStatistics[i][0];
                                            StudentChoices[k][8] = "" + (selection - 1);
                                            ProjectStatistics[i][3] = "" + (Integer.parseInt(ProjectStatistics[i][3]) + 1);
                                        }
                                    }
                                } else if (count > Integer.parseInt(ProjectStatistics[i][2])) {
                                    int times = 0;
                                    while (times != Integer.parseInt(ProjectStatistics[i][2])) {
                                        int pos = random.nextInt(StudentChoices.length);
                                        while (!StudentChoices[pos][selection].equals(ProjectStatistics[i][0]) || !StudentChoices[pos][7].equals("0") || !StudentChoices[pos][8].equals("0")) {
                                            pos = random.nextInt(StudentChoices.length);
                                        }
                                        StudentChoices[pos][7] = ProjectStatistics[i][0];
                                        StudentChoices[pos][8] = "" + (selection - 1);
                                        ProjectStatistics[i][3] = "" + (Integer.parseInt(ProjectStatistics[i][3]) + 1);
                                        times++;
                                    }
                                    ProjectStatistics[i][2] = "0";
                                }
                            }
                        }
                    }
                }
                for (int i = 0; i<ProjectStatistics.length;i++){
                    if ((Integer.parseInt(ProjectStatistics[i][3])<Integer.parseInt(ProjectStatistics[i][1]))&&(Integer.parseInt(ProjectStatistics[i][3])*Integer.parseInt(ProjectStatistics[i][1])!=0)){
                        cont = false;
                    }
                }
                if(!cont){
                    int outProj = random.nextInt(ProjectStatistics.length);
                    while ((Integer.parseInt(ProjectStatistics[outProj][3])>=Integer.parseInt(ProjectStatistics[outProj][1]))){
                        outProj = random.nextInt(ProjectStatistics.length);
                    }

                    ProjectStatistics[outProj][1]="0";
                    ProjectStatistics[outProj][2]="0";
                    ProjectStatistics[outProj][3]="0";
                    for (int i = 0; i<ProjectStatistics.length;i++){
                        int sum =(Integer.parseInt(ProjectStatistics[i][2])+Integer.parseInt( ProjectStatistics[i][3]));
                        ProjectStatistics[i][2]=""+sum;
                        ProjectStatistics[i][3]="0";
                    }

                }
                else if (cont){
                    int z = 0;
                    double sum =0;
                    double exposum = 0;
                    int stud = 0;
                    for (int i= 0 ; i<StudentChoices.length;i++){
                        if (StudentChoices[i][8].equals("0")||StudentChoices[i][8].equals("1")||StudentChoices[i][8].equals("2")||StudentChoices[i][8].equals("3")||StudentChoices[i][8].equals("4")||StudentChoices[i][8].equals("5")){
                            stud++;
                            if(StudentChoices[i][8].equals("0")){
                                exposum+=(6^4);
                                sum+=6;
                                z++;
                            }else{
                                exposum+=(Integer.parseInt(StudentChoices[i][8])^4);
                                sum+=Integer.parseInt(StudentChoices[i][8]);
                            }
                        }

                    }

                    exposum/=stud;
                    sum/=stud;
                    if (sum<happy){
                        System.out.println(z);
                        expohappy=exposum;
                        happy=sum;
                        zeroes=z;
                        SAVECHOICES=StudentChoices;
                        SAVEPROJECTS=ProjectStatistics;
                    }
                }
            }




        }

        final double endTime = System.currentTimeMillis();
        System.out.println(((endTime-startTime)/1000)/3600);


        for (int Rowc=0; Rowc<SAVECHOICES.length;Rowc++){
            System.out.print(SAVECHOICES[Rowc][0]+ "\t"+SAVECHOICES[Rowc][1]+ "\t"+SAVECHOICES[Rowc][7]+ "\t"+SAVECHOICES[Rowc][8]);
            System.out.println();
        }
        System.out.print("\n");
        for (int Rowc=0; Rowc<SAVEPROJECTS.length;Rowc++){
            for (int Colc =0; Colc < 4; Colc++){
                System.out.print(SAVEPROJECTS[Rowc][Colc]+ "\t");
            }
            System.out.println();
        }
        System.out.println(happy+"\n"+expohappy+"\n"+zeroes);






//        print(stats,options,choices,choice);


    }








    public static void print(int [][] stats,int options, int [][] choices,String [] choice){
        Printer fr = new Printer("Stats.txt");
        fr.parsestats(stats,options);

        Printer ar = new Printer("Choices.txt");
        ar.parsechoices(choices,choice.length/6);
    }


}
